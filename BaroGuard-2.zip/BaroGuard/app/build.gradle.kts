plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

val vCode = (project.findProperty("versionCode") as String?)?.toIntOrNull() ?: 1

android {
    namespace = "com.baroguard"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.baroguard"
        minSdk = 26
        targetSdk = 36          // Google Play requires API 36 for new apps/updates since 2026-08-31
        versionCode = vCode
        versionName = "1.0.$vCode"
    }
    signingConfigs {
        create("release") {
            // CI injects the private key through environment variables; the committed key is only a fallback.
            val ks = System.getenv("KEYSTORE_FILE")
            storeFile = if (ks != null) file(ks) else file("baroguard.keystore")
            storePassword = System.getenv("KEYSTORE_PASSWORD") ?: "baroguard"
            keyAlias = System.getenv("KEY_ALIAS") ?: "baroguard"
            keyPassword = System.getenv("KEY_PASSWORD") ?: "baroguard"
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }
    // "direct" = sideload APK with the in-app updater; "play" = Play Store bundle (no self-update, no INTERNET).
    flavorDimensions += "dist"
    productFlavors {
        create("direct") { dimension = "dist"; buildConfigField("boolean", "SELF_UPDATE", "true") }
        create("play") { dimension = "dist"; buildConfigField("boolean", "SELF_UPDATE", "false") }
    }
    lint { checkReleaseBuilds = false; abortOnError = false }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true; buildConfig = true }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation(platform("androidx.compose:compose-bom:2024.09.02"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
}
