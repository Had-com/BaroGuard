package com.baroguard

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

object SensorReader {
    fun hasBarometer(ctx: Context) =
        ctx.getSystemService(SensorManager::class.java).getDefaultSensor(Sensor.TYPE_PRESSURE) != null

    suspend fun read(ctx: Context): Float? {
        val sm = ctx.getSystemService(SensorManager::class.java)
        val sensor = sm.getDefaultSensor(Sensor.TYPE_PRESSURE) ?: return null
        return withTimeoutOrNull(5000) {
            suspendCancellableCoroutine<Float> { cont ->
                val l = object : SensorEventListener {
                    override fun onSensorChanged(e: SensorEvent) {
                        sm.unregisterListener(this)
                        if (cont.isActive) cont.resume(e.values[0])
                    }
                    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
                }
                sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_NORMAL)
                cont.invokeOnCancellation { sm.unregisterListener(l) }
            }
        }
    }
}

/** Self-rescheduling chain so intervals below WorkManager's 15-min periodic minimum (e.g. 5 min) work. */
object Scheduler {
    fun start(ctx: Context) = chain(ctx, 0, ExistingWorkPolicy.REPLACE)
    fun next(ctx: Context) = chain(ctx, Prefs(ctx).intervalMin.toLong(), ExistingWorkPolicy.APPEND_OR_REPLACE)

    fun now(ctx: Context) {
        val r = OneTimeWorkRequestBuilder<SampleWorker>().build()
        WorkManager.getInstance(ctx).enqueueUniqueWork("baro_now", ExistingWorkPolicy.REPLACE, r)
    }

    private fun chain(ctx: Context, delayMin: Long, policy: ExistingWorkPolicy) {
        val r = OneTimeWorkRequestBuilder<SampleWorker>()
            .setInitialDelay(delayMin, TimeUnit.MINUTES)
            .setInputData(workDataOf("chain" to true))
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork("baro_chain", policy, r)
    }
}

class SampleWorker(c: Context, p: WorkerParameters) : CoroutineWorker(c, p) {
    override suspend fun doWork(): Result {
        val ctx = applicationContext
        val hpa = SensorReader.read(ctx)
        if (hpa != null) {
            val dao = Db.get(ctx).dao()
            val now = System.currentTimeMillis()
            dao.insert(Reading(ts = now, hpa = hpa))
            dao.deleteBefore(now - 30 * 24 * HOUR)          // 30-day retention
            AlertEngine.evaluate(ctx, dao, now, hpa)
            BaroWidget.updateAll(ctx)
        }
        if (inputData.getBoolean("chain", false)) Scheduler.next(ctx)
        return Result.success()
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED && SensorReader.hasBarometer(ctx)) Scheduler.start(ctx)
    }
}

object AlertEngine {
    suspend fun evaluate(ctx: Context, dao: ReadingDao, now: Long, cur: Float) {
        val p = Prefs(ctx)
        val win = p.windowH * HOUR
        val target = now - win
        val tol = minOf(maxOf(p.intervalMin * 60_000L * 2, 20 * 60_000L), win / 2)
        val past = dao.nearest(target - tol, target + tol, target) ?: return
        val dp = cur - past.hpa
        val key = when {
            dp <= -p.dropHpa -> "drop"
            dp >= p.riseHpa -> "rise"
            else -> return
        }
        if (now - p.lastAlert(key) < win) return      // cooldown: one alert per window
        if (p.inQuietHours()) return
        p.setLastAlert(key, now)
        val u = p.unit
        val title = if (key == "drop") "Rapid pressure drop" else "Rapid pressure rise"
        val text = "Pressure ${if (key == "drop") "fell" else "rose"} ${u.fmt(kotlin.math.abs(dp))} ${u.label} " +
            "in ${p.windowH} h (now ${u.fmt(cur)} ${u.label})."
        notify(ctx, p, title, text, if (key == "drop") 1 else 2)
    }

    private fun notify(ctx: Context, p: Prefs, title: String, text: String, id: Int) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        // Channel settings are immutable once created, so each sound/vibration/priority combo gets its own channel.
        val chId = "alerts_${p.sound}_${p.vibrate}_${p.highPriority}"
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(chId) == null) {
            val ch = NotificationChannel(
                chId, "Pressure alerts",
                if (p.highPriority) NotificationManager.IMPORTANCE_HIGH else NotificationManager.IMPORTANCE_DEFAULT
            )
            if (!p.sound) ch.setSound(null, null)
            ch.enableVibration(p.vibrate)
            nm.createNotificationChannel(ch)
        }
        val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(ctx, chId)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(id, n)
    }
}
