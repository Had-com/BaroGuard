package com.baroguard

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Foreground service that takes a pressure reading every [Prefs.intervalMin] minutes.
 * Android (9+) does not deliver barometer events to apps running in the background, so a foreground
 * service (with its ongoing notification) is what keeps readings and the widget updating while the app is closed.
 */
class SamplerService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val lock = Mutex()
    private var fgOk = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val n = buildNotification("Monitoring barometric pressure")
        fgOk = try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(NOTIF_ID, n)
            true
        } catch (e: Exception) {
            false                                   // Android refused a foreground start from the background
        }
        running = fgOk
        if (!fgOk) stopSelf()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!fgOk) return START_NOT_STICKY
        sample()
        return START_STICKY
    }

    private fun sample() {
        scope.launch {
            lock.withLock {
                val wl = getSystemService(PowerManager::class.java)
                    .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "baroguard:sample")
                wl.acquire(30_000L)
                try {
                    val ctx = applicationContext
                    Sampler.sampleOnce(ctx)
                    val p = Prefs(ctx)
                    val list = Db.get(ctx).dao().since(System.currentTimeMillis() - 4 * HOUR)
                    val tr = computeTrend(list)
                    val text = list.lastOrNull()?.let {
                        "${p.unit.fmt(it.hpa)} ${p.unit.label}" + (tr?.let { t -> " · ${t.arrow} ${t.label}" } ?: "")
                    } ?: "Waiting for first reading"
                    getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
                } finally {
                    if (wl.isHeld) wl.release()
                    scheduleNext()
                }
            }
        }
    }

    private fun scheduleNext() {
        // Inexact alarm that may fire in Doze, so the next sample is not lost while the phone sleeps
        getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(
            AlarmManager.ELAPSED_REALTIME_WAKEUP,
            SystemClock.elapsedRealtime() + Prefs(this).intervalMin * 60_000L,
            tickIntent(this)
        )
    }

    private fun buildNotification(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Background monitoring", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("BaroGuard")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    override fun onDestroy() {
        running = false
        getSystemService(AlarmManager::class.java).cancel(tickIntent(this))
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        @Volatile var running = false
        const val ACTION_TICK = "com.baroguard.TICK"
        private const val NOTIF_ID = 42
        private const val CHANNEL = "monitor"

        private fun tickIntent(ctx: Context) = PendingIntent.getService(
            ctx, 0, Intent(ctx, SamplerService::class.java).setAction(ACTION_TICK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        /** Starts the service (or makes a running one sample now). Silently ignored if Android forbids it. */
        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, SamplerService::class.java).setAction(ACTION_TICK))
            } catch (e: Exception) { /* background start not allowed */ }
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, SamplerService::class.java))
        }

        /** Manual refresh: through the service when enabled, otherwise through a one-off worker. */
        fun sampleNow(ctx: Context) {
            if (Prefs(ctx).monitorService) {
                try {
                    ContextCompat.startForegroundService(ctx, Intent(ctx, SamplerService::class.java).setAction(ACTION_TICK))
                    return
                } catch (e: Exception) { /* fall through */ }
            }
            Scheduler.now(ctx)
        }
    }
}
