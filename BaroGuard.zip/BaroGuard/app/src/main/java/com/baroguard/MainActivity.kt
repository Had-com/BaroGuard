@file:OptIn(ExperimentalMaterial3Api::class)

package com.baroguard

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Paint
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val hasSensor = SensorReader.hasBarometer(this)
        if (hasSensor) {
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            Scheduler.start(this)
        }
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { if (hasSensor) Root() else Unsupported() }
            }
        }
    }
}

@Composable
fun Unsupported() {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Barometer not available", style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Text(
            "This device has no hardware pressure sensor (Sensor.TYPE_PRESSURE), so BaroGuard cannot measure barometric pressure.",
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun Root() {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    var unit by remember { mutableStateOf(prefs.unit) }
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        TabRow(selectedTabIndex = tab) {
            Tab(tab == 0, { tab = 0 }, text = { Text("Graph") })
            Tab(tab == 1, { tab = 1 }, text = { Text("Settings") })
        }
        if (tab == 0) GraphScreen(unit) else SettingsScreen(prefs) { unit = it }
    }
}

private val timeframes = listOf("1h" to 1, "3h" to 3, "6h" to 6, "12h" to 12, "24h" to 24, "48h" to 48, "7d" to 168)

@Composable
fun GraphScreen(unit: PUnit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val db = remember { Db.get(ctx) }
    val since = remember { System.currentTimeMillis() - 7 * 24 * HOUR }
    val readings by remember { db.dao().observeSince(since) }.collectAsState(emptyList())
    val marks by remember { db.markDao().observeSince(since) }.collectAsState(emptyList())
    var hours by remember { mutableIntStateOf(24) }
    var sel by remember { mutableStateOf<Reading?>(null) }
    var selMark by remember { mutableStateOf<Mark?>(null) }
    var showDialog by remember { mutableStateOf(false) }
    val last = readings.lastOrNull()
    val trend = computeTrend(readings)
    val fmt = remember { SimpleDateFormat("d MMM yyyy HH:mm:ss", Locale.getDefault()) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        if (last == null) {
            Text("Waiting for first reading…", style = MaterialTheme.typography.titleMedium)
        } else {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(unit.fmt(last.hpa), style = MaterialTheme.typography.displayMedium)
                Spacer(Modifier.width(8.dp))
                Text(unit.label, Modifier.padding(bottom = 8.dp), style = MaterialTheme.typography.titleMedium)
            }
            if (trend != null) {
                Text(
                    "${trend.arrow} ${trend.label} · ${unit.fmtDelta(trend.ratePerHour)} ${unit.label}/h",
                    style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Chips(timeframes, hours) { hours = it }
        Spacer(Modifier.height(8.dp))
        PressureChart(
            Modifier.weight(1f).fillMaxWidth(), readings, marks, hours, unit, sel, selMark
        ) { r, mk -> sel = r; selMark = mk }
        Spacer(Modifier.height(8.dp))
        val info = selMark?.let { mk ->
            "Mark · ${fmt.format(Date(mk.ts))}" +
                (if (mk.note.isNotBlank()) " — ${mk.note}" else "") +
                (mk.hpa?.let { " — ${unit.fmt(it)} ${unit.label}" } ?: "")
        } ?: sel?.let { "${fmt.format(Date(it.ts))} — ${unit.fmt(it.hpa)} ${unit.label}" }
            ?: "Pinch to zoom · drag to pan · tap to inspect"
        Text(info, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { showDialog = true }) { Text("Add mark") }
            selMark?.let { mk ->
                TextButton(onClick = {
                    selMark = null
                    scope.launch(Dispatchers.IO) { db.markDao().delete(mk) }
                }) { Text("Delete mark") }
            }
        }
    }

    if (showDialog) {
        MarkDialog(onDismiss = { showDialog = false }) { note ->
            showDialog = false
            scope.launch(Dispatchers.IO) {
                val now = System.currentTimeMillis()
                val h = SensorReader.read(ctx)                       // fresh reading so the mark sits on the curve
                if (h != null) db.dao().insert(Reading(ts = now, hpa = h))
                db.markDao().insert(Mark(ts = now, hpa = h ?: readings.lastOrNull()?.hpa, note = note))
                BaroWidget.updateAll(ctx)
            }
        }
    }
}

@Composable
fun MarkDialog(onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add mark") },
        text = {
            OutlinedTextField(
                note, { note = it }, singleLine = true,
                label = { Text("Note (optional), e.g. headache") }
            )
        },
        confirmButton = { TextButton(onClick = { onSave(note.trim()) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun PressureChart(
    modifier: Modifier, all: List<Reading>, marks: List<Mark>, hours: Int, unit: PUnit,
    selected: Reading?, selectedMark: Mark?, onSelect: (Reading?, Mark?) -> Unit
) {
    val latest = all.lastOrNull()?.ts ?: System.currentTimeMillis()
    val oldest = all.firstOrNull()?.ts ?: latest
    val latestS by rememberUpdatedState(latest)
    val oldestS by rememberUpdatedState(oldest)
    val allS by rememberUpdatedState(all)
    val marksS by rememberUpdatedState(marks)
    val segs = remember(all) { computeSegments(all) }
    val onSelectS by rememberUpdatedState(onSelect)

    var span by remember(hours) { mutableDoubleStateOf(hours * HOUR.toDouble()) }   // visible window (ms)
    var back by remember(hours) { mutableDoubleStateOf(0.0) }                       // pan offset from latest (ms)

    val line = MaterialTheme.colorScheme.primary
    val grid = MaterialTheme.colorScheme.outlineVariant
    val markColor = MaterialTheme.colorScheme.tertiary
    val txt = MaterialTheme.colorScheme.onSurfaceVariant.toArgb()
    val density = LocalDensity.current
    val paint = remember(txt, density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply { color = txt; textSize = with(density) { 11.sp.toPx() } }
    }
    val ratePaint = remember(paint) {
        Paint(paint).apply { textAlign = Paint.Align.CENTER; isFakeBoldText = true }
    }
    val padL = with(density) { 52.dp.toPx() }
    val padR = with(density) { 8.dp.toPx() }
    val padT = with(density) { 8.dp.toPx() }
    val padB = with(density) { 22.dp.toPx() }
    val hm = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val dm = remember { SimpleDateFormat("d MMM", Locale.getDefault()) }

    Canvas(
        modifier
            .pointerInput(Unit) {
                detectTransformGestures { c, pan, zoom, _ ->
                    val plotW = (size.width - padL - padR).coerceAtLeast(1f)
                    val vEnd = latestS - back
                    val f = ((c.x - padL) / plotW).coerceIn(0f, 1f)
                    val t = vEnd - span * (1 - f)
                    val ns = (span / zoom).coerceIn(10 * 60_000.0, 7 * 24 * HOUR.toDouble())
                    var ne = t + ns * (1 - f)
                    ne -= pan.x / plotW * ns
                    ne = ne.coerceIn(oldestS.toDouble(), latestS.toDouble())
                    span = ns
                    back = latestS - ne
                }
            }
            .pointerInput(Unit) {
                detectTapGestures { o ->
                    val plotW = (size.width - padL - padR).coerceAtLeast(1f)
                    val vStart = latestS - back - span
                    val tt = vStart + (o.x - padL) / plotW * span
                    val mk = marksS.minByOrNull { abs(it.ts - tt) }
                    val tol = 24.dp.toPx() / plotW * span
                    if (mk != null && abs(mk.ts - tt) <= tol) onSelectS(null, mk)
                    else onSelectS(allS.minByOrNull { abs(it.ts - tt) }, null)
                }
            }
    ) {
        val plotW = size.width - padL - padR
        val plotH = size.height - padT - padB
        val vEnd = latest - back
        val vStart = vEnd - span
        val vis = all.filter { it.ts >= vStart - span * 0.1 && it.ts <= vEnd + span * 0.1 }
        if (vis.isEmpty()) return@Canvas
        val inView = vis.filter { it.ts >= vStart && it.ts <= vEnd }.ifEmpty { vis }

        var lo = inView.minOf { unit.conv(it.hpa) }
        var hi = inView.maxOf { unit.conv(it.hpa) }
        val minRange = unit.conv(0.5f)
        if (hi - lo < minRange) { val m = (hi + lo) / 2; lo = m - minRange / 2; hi = m + minRange / 2 }
        val pad = (hi - lo) * 0.1f
        lo -= pad; hi += pad

        fun xOf(t: Long) = padL + ((t - vStart) / span * plotW).toFloat()
        fun yOf(v: Float) = padT + plotH * (1 - (v - lo) / (hi - lo))

        drawIntoCanvas { cv ->
            val nc = cv.nativeCanvas
            for (i in 0..4) {
                val y = padT + plotH * i / 4
                drawLine(grid, Offset(padL, y), Offset(padL + plotW, y))
                val v = hi - (hi - lo) * i / 4
                nc.drawText(String.format(Locale.getDefault(), "%.${unit.dec}f", v), 4f, y + paint.textSize / 3, paint)
            }
            for (i in 0..3) {
                val tm = (vStart + span * i / 3).toLong()
                val s = if (span <= 30 * HOUR) hm.format(Date(tm)) else dm.format(Date(tm))
                val x = (padL + plotW * i / 3 - paint.measureText(s) / 2).coerceIn(0f, size.width - paint.measureText(s))
                nc.drawText(s, x, size.height - 4f, paint)
            }
            // One segment per rise/fall run: divider at each turning point and the rate in the middle
            segs.forEach { sg ->
                val ta = sg.pts.first().ts
                val tb = sg.pts.last().ts
                if (tb < vStart || ta > vEnd) return@forEach
                if (ta > vStart) {
                    val sx = xOf(ta)
                    drawLine(grid.copy(alpha = 0.6f), Offset(sx, padT), Offset(sx, padT + plotH))
                }
                val x0 = xOf(ta).coerceAtLeast(padL)
                val x1 = xOf(tb).coerceAtMost(padL + plotW)
                val r = sg.rate
                val arrow = if (r >= 0.3f) "↑" else if (r <= -0.3f) "↓" else "→"
                val label = "$arrow ${unit.fmtDelta(r)} ${unit.label}/h"
                ratePaint.color = when {
                    r >= 0.3f -> 0xFF43A047.toInt()
                    r <= -0.3f -> 0xFFE53935.toInt()
                    else -> txt
                }
                if (x1 - x0 >= ratePaint.measureText(label) + 8f)      // only label segments wide enough
                    nc.drawText(label, (x0 + x1) / 2, padT + plotH - 6.dp.toPx(), ratePaint)
            }
        }

        clipRect(padL, padT, padL + plotW, padT + plotH) {
            segs.forEach { sg ->
                if (sg.pts.last().ts < vStart || sg.pts.first().ts > vEnd) return@forEach
                val path = Path()
                sg.pts.forEachIndexed { i, r ->
                    val x = xOf(r.ts); val y = yOf(unit.conv(r.hpa))
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                val col = when {
                    sg.rate >= 0.3f -> Color(0xFF43A047)
                    sg.rate <= -0.3f -> Color(0xFFE53935)
                    else -> line
                }
                drawPath(path, col, style = Stroke(2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            marks.forEach { mk ->
                if (mk.ts >= vStart && mk.ts <= vEnd) {
                    val x = xOf(mk.ts)
                    val c = if (mk.id == selectedMark?.id) line else markColor
                    drawLine(
                        c, Offset(x, padT), Offset(x, padT + plotH), strokeWidth = 2.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 10f))
                    )
                    drawCircle(c, 6.dp.toPx(), Offset(x, padT + 8.dp.toPx()))
                }
            }
            if (selected != null) {
                val x = xOf(selected.ts)
                drawLine(line.copy(alpha = 0.4f), Offset(x, padT), Offset(x, padT + plotH))
                drawCircle(line, 5.dp.toPx(), Offset(x, yOf(unit.conv(selected.hpa))))
            }
        }
    }
}

// ---------------- Settings ----------------

@Composable
fun SettingsScreen(p: Prefs, onUnit: (PUnit) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var interval by remember { mutableIntStateOf(p.intervalMin) }
    var unit by remember { mutableStateOf(p.unit) }
    var drop by remember { mutableFloatStateOf(p.dropHpa) }
    var rise by remember { mutableFloatStateOf(p.riseHpa) }
    var window by remember { mutableIntStateOf(p.windowH) }
    var sound by remember { mutableStateOf(p.sound) }
    var vibrate by remember { mutableStateOf(p.vibrate) }
    var high by remember { mutableStateOf(p.highPriority) }
    var quiet by remember { mutableStateOf(p.quietOn) }
    var qs by remember { mutableIntStateOf(p.quietStart) }
    var qe by remember { mutableIntStateOf(p.quietEnd) }
    var wh by remember { mutableIntStateOf(p.widgetHours) }
    var wbg by remember { mutableIntStateOf(p.widgetBg) }
    var walpha by remember { mutableIntStateOf(p.widgetAlpha) }

    fun refreshWidget() { scope.launch(Dispatchers.IO) { BaroWidget.updateAll(ctx) } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Section("Sampling interval")
        Chips(listOf("5 min" to 5, "15 min" to 15, "30 min" to 30, "60 min" to 60), interval) {
            interval = it; p.intervalMin = it; Scheduler.start(ctx)
        }
        Section("Units")
        Chips(PUnit.values().map { it.label to it }, unit) {
            unit = it; p.unit = it; onUnit(it); refreshWidget()
        }

        Section("Alerts")
        SliderRow("Rapid drop threshold: ${"%.1f".format(drop)} hPa", drop, 0.5f..10f, 18) { drop = it; p.dropHpa = it }
        SliderRow("Rapid rise threshold: ${"%.1f".format(rise)} hPa", rise, 0.5f..10f, 18) { rise = it; p.riseHpa = it }
        SliderRow("Time window: $window h", window.toFloat(), 1f..12f, 10) { window = it.toInt(); p.windowH = window }
        SwitchRow("Sound", sound) { sound = it; p.sound = it }
        SwitchRow("Vibration", vibrate) { vibrate = it; p.vibrate = it }
        SwitchRow("High priority (heads-up)", high) { high = it; p.highPriority = it }

        Section("Quiet hours")
        SwitchRow("Silence alerts during quiet hours", quiet) { quiet = it; p.quietOn = it }
        if (quiet) {
            SliderRow("From ${"%02d".format(qs)}:00", qs.toFloat(), 0f..23f, 22) { qs = it.toInt(); p.quietStart = qs }
            SliderRow("To ${"%02d".format(qe)}:00", qe.toFloat(), 0f..23f, 22) { qe = it.toInt(); p.quietEnd = qe }
        }
        Text(
            "System Do Not Disturb is also respected automatically.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Section("Widget chart range")
        Chips(listOf("1 h" to 1, "3 h" to 3, "6 h" to 6, "12 h" to 12, "24 h" to 24), wh) {
            wh = it; p.widgetHours = it; refreshWidget()
        }

        Section("Widget background")
        val presets = listOf(0x1B2430, 0x000000, 0x37474F, 0x1B3A2A, 0x3B1C2A, 0xF5F0E6, 0xFFFFFF)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            presets.forEach { c ->
                val on = wbg == c
                Box(
                    Modifier.size(38.dp).clip(CircleShape).background(Color(0xFF000000.toInt() or c))
                        .border(
                            if (on) 3.dp else 1.dp,
                            if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                            CircleShape
                        )
                        .clickable { wbg = c; p.widgetBg = c; refreshWidget() }
                )
            }
        }
        SliderRow("Red: ${(wbg shr 16) and 255}", ((wbg shr 16) and 255).toFloat(), 0f..255f, 0,
            onFinished = { refreshWidget() }) { wbg = (wbg and 0x00FFFF) or (it.toInt() shl 16); p.widgetBg = wbg }
        SliderRow("Green: ${(wbg shr 8) and 255}", ((wbg shr 8) and 255).toFloat(), 0f..255f, 0,
            onFinished = { refreshWidget() }) { wbg = (wbg and 0xFF00FF) or (it.toInt() shl 8); p.widgetBg = wbg }
        SliderRow("Blue: ${wbg and 255}", (wbg and 255).toFloat(), 0f..255f, 0,
            onFinished = { refreshWidget() }) { wbg = (wbg and 0xFFFF00) or it.toInt(); p.widgetBg = wbg }
        SliderRow("Opacity: ${walpha * 100 / 255}%", walpha.toFloat(), 40f..255f, 0,
            onFinished = { refreshWidget() }) { walpha = it.toInt(); p.widgetAlpha = walpha }

        if (BuildConfig.SELF_UPDATE) UpdateSection()
    }
}

@Composable
fun Section(t: String) = Text(
    t, Modifier.padding(top = 20.dp, bottom = 6.dp),
    style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary
)

@Composable
fun <T> Chips(options: List<Pair<String, T>>, selected: T, onSelect: (T) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (label, v) -> FilterChip(selected == v, { onSelect(v) }, label = { Text(label) }) }
    }
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f)); Switch(checked, onChange)
    }
}

@Composable
fun SliderRow(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>, steps: Int,
    onFinished: () -> Unit = {}, onChange: (Float) -> Unit
) {
    Column { Text(label); Slider(value, onChange, valueRange = range, steps = steps, onValueChangeFinished = onFinished) }
}

// ---------------- Updates ----------------

sealed interface UState {
    data object Idle : UState
    data object Checking : UState
    data object UpToDate : UState
    data class Available(val info: Updater.Info) : UState
    data class Downloading(val info: Updater.Info, val pct: Int) : UState
}

@Composable
fun UpdateSection() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var us by remember { mutableStateOf<UState>(UState.Idle) }
    var msg by remember { mutableStateOf<String?>(null) }
    val s = us

    Section("App updates")
    Text("Installed version: ${Updater.installedName(ctx)}")
    when (s) {
        UState.Idle -> {}
        UState.Checking -> Text("Checking for updates…")
        UState.UpToDate -> Text("You have the latest version.")
        is UState.Available -> {
            Text("Update available: ${s.info.name}", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("What's new", style = MaterialTheme.typography.titleSmall)
            s.info.changes.forEach { r ->
                Spacer(Modifier.height(6.dp))
                Text("Version ${r.name}", fontWeight = FontWeight.SemiBold)
                Text(r.notes.ifBlank { "No release notes." }, style = MaterialTheme.typography.bodyMedium)
            }
        }
        is UState.Downloading -> {
            LinearProgressIndicator(progress = { s.pct / 100f }, modifier = Modifier.fillMaxWidth())
            Text("Downloading… ${s.pct}%")
        }
    }
    msg?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(
            enabled = s !is UState.Checking && s !is UState.Downloading,
            onClick = {
                msg = null
                us = UState.Checking
                scope.launch {
                    try {
                        val i = Updater.check(Updater.installedCode(ctx))
                        us = if (i != null) UState.Available(i) else UState.UpToDate
                    } catch (e: Exception) {
                        us = UState.Idle
                        msg = "Could not check for updates: ${e.message}"
                    }
                }
            }
        ) { Text("Check for updates") }

        if (s is UState.Available) {
            Button(onClick = {
                if (!Updater.canInstall(ctx)) {
                    Updater.openInstallSettings(ctx)
                    msg = "Allow installs from BaroGuard, go back, then tap Install update again."
                    return@Button
                }
                msg = null
                scope.launch {
                    try {
                        val f = Updater.download(ctx, s.info.url) { us = UState.Downloading(s.info, it) }
                        us = UState.Available(s.info)
                        Updater.install(ctx, f)
                    } catch (e: Exception) {
                        us = UState.Available(s.info)
                        msg = "Download failed: ${e.message}"
                    }
                }
            }) { Text("Install update") }
        }
    }
}
