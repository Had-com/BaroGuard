package com.baroguard

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.FileProvider
import androidx.core.content.pm.PackageInfoCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Checks GitHub Releases and installs the newest APK. Tags look like v1.0.<versionCode>. */
object Updater {
    private const val REPO = "Had-com/BaroGuard"
    private val CODE = Regex("""(\d+)$""")

    /** One released version and its summary of changes. */
    data class Release(val code: Long, val name: String, val notes: String)

    /** [changes] = every release newer than the installed one (newest first), each with its notes. */
    data class Info(val code: Long, val name: String, val url: String, val changes: List<Release>)

    private data class Rel(val code: Long, val name: String, val notes: String, val url: String?)

    fun installedCode(ctx: Context): Long =
        PackageInfoCompat.getLongVersionCode(ctx.packageManager.getPackageInfo(ctx.packageName, 0))

    fun installedName(ctx: Context): String =
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "?"

    /** Returns null when the installed version is already the newest. */
    suspend fun check(installed: Long): Info? = withContext(Dispatchers.IO) {
        val c = URL("https://api.github.com/repos/$REPO/releases?per_page=20").openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 10_000
        c.setRequestProperty("Accept", "application/vnd.github+json")
        if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode}")
        val arr = JSONArray(c.inputStream.bufferedReader().use { it.readText() })

        val rels = (0 until arr.length()).mapNotNull { i ->
            val j = arr.getJSONObject(i)
            if (j.optBoolean("draft") || j.optBoolean("prerelease")) return@mapNotNull null
            val tag = j.getString("tag_name")
            val code = CODE.find(tag)?.value?.toLongOrNull() ?: return@mapNotNull null
            val assets = j.getJSONArray("assets")
            var url: String? = null
            for (k in 0 until assets.length()) {
                val a = assets.getJSONObject(k)
                if (a.getString("name").endsWith(".apk")) url = a.getString("browser_download_url")
            }
            Rel(code, tag.removePrefix("v"), cleanNotes(if (j.isNull("body")) "" else j.getString("body")), url)
        }
        val latest = rels.filter { it.url != null }.maxByOrNull { it.code } ?: throw IOException("no release with an APK found")
        if (latest.code <= installed) return@withContext null
        Info(
            latest.code, latest.name, latest.url!!,
            rels.filter { it.code > installed && it.code <= latest.code }
                .sortedByDescending { it.code }.take(8)
                .map { Release(it.code, it.name, it.notes) }
        )
    }

    /** Turns simple Markdown into plain text: bullets become "•", headings lose their #. */
    private fun cleanNotes(md: String): String =
        md.replace("\r", "").lines().joinToString("\n") {
            it.replace(Regex("""^\s*[-*]\s+"""), "• ").replace(Regex("""^#+\s*"""), "")
        }.trim()

    suspend fun download(ctx: Context, url: String, onProgress: (Int) -> Unit): File = withContext(Dispatchers.IO) {
        val dir = File(ctx.cacheDir, "updates").apply { mkdirs() }
        val f = File(dir, "BaroGuard.apk")
        val c = URL(url).openConnection() as HttpURLConnection   // follows GitHub's HTTPS redirect
        c.connectTimeout = 15_000
        c.readTimeout = 30_000
        if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode}")
        val total = c.contentLengthLong
        c.inputStream.use { input ->
            f.outputStream().use { out ->
                val buf = ByteArray(32 * 1024)
                var read = 0L
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    read += n
                    if (total > 0) onProgress((read * 100 / total).toInt())
                }
            }
        }
        f
    }

    fun canInstall(ctx: Context) = ctx.packageManager.canRequestPackageInstalls()

    fun openInstallSettings(ctx: Context) {
        ctx.startActivity(
            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    fun install(ctx: Context, apk: File) {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", apk)
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
