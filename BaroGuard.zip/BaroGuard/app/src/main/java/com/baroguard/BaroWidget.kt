package com.baroguard

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.text.format.DateFormat
import android.widget.RemoteViews
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Date

object ChartBitmap {
    fun render(list: List<Reading>, w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        if (list.size < 2) return bmp
        val minT = list.first().ts
        val maxT = list.last().ts
        var lo = list.minOf { it.hpa }
        var hi = list.maxOf { it.hpa }
        if (hi - lo < 1f) { val m = (hi + lo) / 2; lo = m - 0.5f; hi = m + 0.5f }
        val pad = 8f
        val span = (maxT - minT).coerceAtLeast(1L).toFloat()
        val path = Path()
        list.forEachIndexed { i, r ->
            val x = pad + (r.ts - minT) / span * (w - 2 * pad)
            val y = pad + (1 - (r.hpa - lo) / (hi - lo)) * (h - 2 * pad)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 5f; color = 0xFF64B5F6.toInt(); strokeJoin = Paint.Join.ROUND
        }
        Canvas(bmp).drawPath(path, paint)
        return bmp
    }
}

class BaroWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val pr = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try { push(ctx, mgr, ids) } finally { pr.finish() }
        }
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == ACTION_REFRESH) Scheduler.now(ctx) else super.onReceive(ctx, intent)
    }

    companion object {
        const val ACTION_REFRESH = "com.baroguard.REFRESH"

        suspend fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            push(ctx, mgr, mgr.getAppWidgetIds(ComponentName(ctx, BaroWidget::class.java)))
        }

        private suspend fun push(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
            if (ids.isEmpty()) return
            val p = Prefs(ctx)
            val now = System.currentTimeMillis()
            val list = Db.get(ctx).dao().since(now - 24 * HOUR)
            val last = list.lastOrNull()
            val tr = computeTrend(list)
            val u = p.unit
            val bmp = ChartBitmap.render(list.filter { it.ts >= now - p.widgetHours * HOUR }, 640, 220)

            val rv = RemoteViews(ctx.packageName, R.layout.widget_baroguard)
            rv.setTextViewText(R.id.w_value, last?.let { u.fmt(it.hpa) } ?: "--")
            rv.setTextViewText(R.id.w_unit, u.label)
            rv.setTextViewText(R.id.w_trend, tr?.let { "${it.arrow} ${it.label}" } ?: "")
            rv.setTextViewText(
                R.id.w_updated,
                last?.let { "Updated " + DateFormat.getTimeFormat(ctx).format(Date(it.ts)) } ?: "No data yet"
            )
            rv.setImageViewBitmap(R.id.w_chart, bmp)

            val refresh = PendingIntent.getBroadcast(
                ctx, 0, Intent(ctx, BaroWidget::class.java).setAction(ACTION_REFRESH),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.w_refresh, refresh)
            val open = PendingIntent.getActivity(ctx, 1, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            rv.setOnClickPendingIntent(R.id.w_root, open)
            mgr.updateAppWidget(ids, rv)
        }
    }
}
