package com.baroguard

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.os.Bundle
import androidx.core.graphics.ColorUtils
import android.text.format.DateFormat
import android.widget.RemoteViews
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Colours for the widget, chosen from the background's brightness so text stays readable. */
class WPal(val light: Boolean) {
    val main = if (light) 0xFF101820.toInt() else 0xFFFFFFFF.toInt()
    val text = if (light) 0xFF455A64.toInt() else 0xFFB0BEC5.toInt()
    val sub = if (light) 0xFF607D8B.toInt() else 0xFF90A4AE.toInt()
    val red = if (light) 0xFFD32F2F.toInt() else 0xFFEF5350.toInt()
    val green = if (light) 0xFF2E7D32.toInt() else 0xFF66BB6A.toInt()
    val blue = if (light) 0xFF1565C0.toInt() else 0xFF64B5F6.toInt()
    val mark = if (light) 0xFFEF6C00.toInt() else 0xFFFFB74D.toInt()
    val grid = if (light) 0x33000000 else 0x33FFFFFF
    val dot = main
}

/** Draws the widget graph: same information as the in-app chart. */
object ChartBitmap {
    fun render(readings: List<Reading>, marks: List<Mark>, p: Prefs, pal: WPal, w: Int, h: Int, d: Float): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val u = p.unit
        val spanData = p.widgetHours * HOUR
        val end = readings.lastOrNull()?.ts ?: System.currentTimeMillis()
        val vStart = end - spanData
        val vEnd = vStart + spanData * 4 / 3            // latest reading sits at 3/4 of the x axis, 1/4 stays empty
        val data = readings.filter { it.ts >= vStart }

        val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = pal.text; textSize = 10.5f * d }
        if (data.size < 2) {
            txt.textAlign = Paint.Align.CENTER
            cv.drawText("Collecting data…", w / 2f, h / 2f, txt)
            return bmp
        }

        // ---- y range (values shown in the chosen unit) ----
        var lo = data.minOf { u.conv(it.hpa) }
        var hi = data.maxOf { u.conv(it.hpa) }
        val minRange = u.conv(0.5f)
        if (hi - lo < minRange) { val m = (hi + lo) / 2; lo = m - minRange / 2; hi = m + minRange / 2 }
        val pad = (hi - lo) * 0.1f
        lo -= pad; hi += pad
        val labels = (0..2).map { String.format(Locale.getDefault(), "%.${u.dec}f", hi - (hi - lo) * it / 2) }

        val padL = labels.maxOf { txt.measureText(it) } + 8 * d
        val padT = 14 * d
        val padB = 18 * d
        val padR = 6 * d
        val plotW = w - padL - padR
        val plotH = h - padT - padB
        fun xOf(t: Long) = padL + ((t - vStart).toDouble() / (vEnd - vStart) * plotW).toFloat()
        fun yOf(v: Float) = padT + plotH * (1 - (v - lo) / (hi - lo))
        fun paint(c: Int, style: Paint.Style, sw: Float = 0f) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = c; this.style = style; strokeWidth = sw; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }

        val segs = computeSegments(data)
        val highDrop = p.dropHpa / p.windowH       // hPa/h that would trigger the rapid-drop alert
        val highRise = p.riseHpa / p.windowH
        fun colorOf(r: Float) = if (r >= 0.3f) pal.green else if (r <= -0.3f) pal.red else pal.blue
        fun isHigh(r: Float) = r <= -highDrop || r >= highRise

        // ---- highlight bands behind strong rises / drops ----
        segs.forEach { sg ->
            if (isHigh(sg.rate)) {
                val band = paint(colorOf(sg.rate), Paint.Style.FILL).apply { alpha = 45 }
                cv.drawRect(xOf(sg.pts.first().ts), padT, xOf(sg.pts.last().ts), padT + plotH, band)
            }
        }

        // ---- axes: grid, y values, unit ----
        val grid = paint(pal.grid, Paint.Style.STROKE, 1f * d)
        for (i in 0..2) {
            val y = padT + plotH * i / 2
            cv.drawLine(padL, y, padL + plotW, y, grid)
            cv.drawText(labels[i], 2 * d, y + txt.textSize / 3, txt)
        }
        cv.drawText(u.label, 2 * d, padT - 3 * d, txt)
        val tf = SimpleDateFormat("HH:mm", Locale.getDefault())
        for (i in 0..3) {
            val t = vStart + spanData * i / 3
            val s = tf.format(Date(t))
            val x = (xOf(t) - txt.measureText(s) / 2).coerceIn(0f, w - txt.measureText(s))
            cv.drawText(s, x, h - 4 * d, txt)
        }

        // ---- segments: coloured line, dividers at turning points, rate labels ----
        val rateTxt = Paint(txt).apply { textAlign = Paint.Align.CENTER; isFakeBoldText = true }
        segs.forEachIndexed { idx, sg ->
            val r = sg.rate
            val high = isHigh(r)
            val col = colorOf(r)
            val xa = xOf(sg.pts.first().ts)
            val xb = xOf(sg.pts.last().ts)
            if (idx > 0) cv.drawLine(xa, padT, xa, padT + plotH, grid)

            val path = Path()
            sg.pts.forEachIndexed { i, pt ->
                val x = xOf(pt.ts); val y = yOf(u.conv(pt.hpa))
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            cv.drawPath(path, paint(col, Paint.Style.STROKE, (if (high) 3.5f else 2.2f) * d))

            val arrow = if (high) (if (r > 0) "▲" else "▼") else if (r >= 0.3f) "↑" else if (r <= -0.3f) "↓" else "→"
            val full = "$arrow ${u.fmtDelta(r)} ${u.label}/h"
            val short = "$arrow ${u.fmtDelta(r)}"
            val avail = xb - xa - 4 * d
            val label = when {
                rateTxt.measureText(full) <= avail -> full
                rateTxt.measureText(short) <= avail -> short
                else -> null
            }
            if (label != null) {
                rateTxt.color = col
                cv.drawText(label, (xa + xb) / 2, padT + plotH - 4 * d, rateTxt)
            }
        }

        // ---- marks ----
        val markLine = paint(pal.mark, Paint.Style.STROKE, 1.5f * d).apply { pathEffect = DashPathEffect(floatArrayOf(6 * d, 5 * d), 0f) }
        val markDot = paint(pal.mark, Paint.Style.FILL)
        marks.forEach { m ->
            if (m.ts in vStart..end) {
                val x = xOf(m.ts)
                cv.drawLine(x, padT, x, padT + plotH, markLine)
                cv.drawCircle(x, padT + 4 * d, 3.5f * d, markDot)
            }
        }

        // ---- end point ----
        val last = data.last()
        cv.drawCircle(xOf(last.ts), yOf(u.conv(last.hpa)), 4 * d, paint(pal.dot, Paint.Style.FILL))
        return bmp
    }
}

class BaroWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val pr = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try { push(ctx, mgr, ids) } finally { pr.finish() }
        }
    }

    override fun onAppWidgetOptionsChanged(ctx: Context, mgr: AppWidgetManager, id: Int, newOptions: Bundle) {
        val pr = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try { push(ctx, mgr, intArrayOf(id)) } finally { pr.finish() }
        }
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        when (intent.action) {
            ACTION_REFRESH -> Scheduler.now(ctx)
            ACTION_RANGE -> {
                Prefs(ctx).widgetHours = intent.getIntExtra("hours", 12)
                val pr = goAsync()
                CoroutineScope(Dispatchers.IO).launch { try { updateAll(ctx) } finally { pr.finish() } }
            }
            else -> super.onReceive(ctx, intent)
        }
    }

    companion object {
        const val ACTION_REFRESH = "com.baroguard.REFRESH"
        const val ACTION_RANGE = "com.baroguard.RANGE"
        private val RANGES = listOf(1 to R.id.w_r1, 3 to R.id.w_r3, 6 to R.id.w_r6, 12 to R.id.w_r12, 24 to R.id.w_r24)

        suspend fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            push(ctx, mgr, mgr.getAppWidgetIds(ComponentName(ctx, BaroWidget::class.java)))
        }

        private suspend fun push(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
            if (ids.isEmpty()) return
            val p = Prefs(ctx)
            val db = Db.get(ctx)
            val now = System.currentTimeMillis()
            val since = now - 24 * HOUR
            val list = db.dao().since(since)
            val marks = db.markDao().since(since)
            val last = list.lastOrNull()
            val tr = computeTrend(list)
            val u = p.unit
            val d = ctx.resources.displayMetrics.density

            val refresh = PendingIntent.getBroadcast(
                ctx, 0, Intent(ctx, BaroWidget::class.java).setAction(ACTION_REFRESH),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val open = PendingIntent.getActivity(ctx, 1, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)

            for (id in ids) {
                // Render the chart at the widget's real size so text and lines are not stretched
                val o = mgr.getAppWidgetOptions(id)
                val wDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0).takeIf { it > 0 } ?: 320
                val hDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0).takeIf { it > 0 } ?: 180
                var wPx = ((wDp - 16) * d).toInt().coerceAtLeast(240)
                var hPx = ((hDp - 16 - 40 - 26) * d).toInt().coerceAtLeast(120)
                val maxArea = 900_000f                                  // keep the bitmap small for RemoteViews
                if (wPx.toFloat() * hPx > maxArea) {
                    val k = Math.sqrt((maxArea / (wPx.toFloat() * hPx)).toDouble()).toFloat()
                    wPx = (wPx * k).toInt(); hPx = (hPx * k).toInt()
                }
                val dd = d * wPx / ((wDp - 16) * d).coerceAtLeast(1f)  // text scale follows any downscaling
                val bg = p.widgetBg
                val pal = WPal(ColorUtils.calculateLuminance(bg or 0xFF000000.toInt()) > 0.5)
                val bmp = ChartBitmap.render(list, marks, p, pal, wPx, hPx, dd)

                val rv = RemoteViews(ctx.packageName, R.layout.widget_baroguard)
                rv.setTextViewText(R.id.w_value, last?.let { u.fmt(it.hpa) } ?: "--")
                rv.setTextViewText(R.id.w_unit, u.label)
                rv.setTextViewText(R.id.w_trend, tr?.let { "${it.arrow} ${it.label} · ${u.fmtDelta(it.ratePerHour)}/h" } ?: "")
                rv.setTextColor(R.id.w_trend, when (tr?.label) { "Rising" -> pal.green; "Falling" -> pal.red; else -> pal.blue })
                rv.setTextColor(R.id.w_value, pal.main)
                rv.setTextColor(R.id.w_unit, pal.text)
                rv.setTextColor(R.id.w_updated, pal.sub)
                rv.setInt(R.id.w_refresh, "setColorFilter", pal.text)
                rv.setInt(R.id.w_bg, "setColorFilter", bg or 0xFF000000.toInt())   // background colour...
                rv.setInt(R.id.w_bg, "setImageAlpha", p.widgetAlpha)                 // ...and opacity
                for ((hrs, vid) in RANGES) {
                    val on = hrs == p.widgetHours
                    rv.setTextColor(vid, if (on) pal.blue else pal.text)
                    rv.setInt(vid, "setBackgroundResource", if (on) R.drawable.range_sel else 0)
                    rv.setOnClickPendingIntent(
                        vid,
                        PendingIntent.getBroadcast(
                            ctx, 100 + hrs, Intent(ctx, BaroWidget::class.java).setAction(ACTION_RANGE).putExtra("hours", hrs),
                            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                        )
                    )
                }
                rv.setTextViewText(
                    R.id.w_updated,
                    last?.let { "Updated " + DateFormat.getTimeFormat(ctx).format(Date(it.ts)) } ?: "No data yet"
                )
                rv.setImageViewBitmap(R.id.w_chart, bmp)
                rv.setOnClickPendingIntent(R.id.w_refresh, refresh)
                rv.setOnClickPendingIntent(R.id.w_root, open)
                mgr.updateAppWidget(id, rv)
            }
        }
    }
}
