package com.baroguard

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "readings", indices = [Index("ts")])
data class Reading(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ts: Long,
    val hpa: Float
)

@Dao
interface ReadingDao {
    @Insert suspend fun insert(r: Reading)
    @Query("SELECT * FROM readings WHERE ts >= :since ORDER BY ts") fun observeSince(since: Long): Flow<List<Reading>>
    @Query("SELECT * FROM readings WHERE ts >= :since ORDER BY ts") suspend fun since(since: Long): List<Reading>
    @Query("SELECT * FROM readings WHERE ts BETWEEN :from AND :to ORDER BY ABS(ts - :target) LIMIT 1")
    suspend fun nearest(from: Long, to: Long, target: Long): Reading?
    @Query("DELETE FROM readings WHERE ts < :before") suspend fun deleteBefore(before: Long)
}

@Database(entities = [Reading::class], version = 1, exportSchema = false)
abstract class Db : RoomDatabase() {
    abstract fun dao(): ReadingDao

    companion object {
        @Volatile private var inst: Db? = null
        fun get(ctx: Context): Db = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, Db::class.java, "baroguard.db").build().also { inst = it }
        }
    }
}
