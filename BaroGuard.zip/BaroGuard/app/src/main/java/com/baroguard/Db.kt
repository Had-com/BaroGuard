package com.baroguard

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "readings", indices = [Index("ts")])
data class Reading(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ts: Long,
    val hpa: Float
)

/** A user-placed marker on the graph (e.g. "headache started"). hpa is the pressure measured when it was added. */
@Entity(tableName = "marks", indices = [Index("ts")])
data class Mark(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ts: Long,
    val hpa: Float?,
    val note: String = ""
)

@Dao
interface MarkDao {
    @Insert suspend fun insert(m: Mark)
    @Query("SELECT * FROM marks WHERE ts >= :since ORDER BY ts") fun observeSince(since: Long): Flow<List<Mark>>
    @Query("SELECT * FROM marks WHERE ts >= :since ORDER BY ts") suspend fun since(since: Long): List<Mark>
    @Delete suspend fun delete(m: Mark)
}

@Dao
interface ReadingDao {
    @Insert suspend fun insert(r: Reading)
    @Query("SELECT * FROM readings WHERE ts >= :since ORDER BY ts") fun observeSince(since: Long): Flow<List<Reading>>
    @Query("SELECT * FROM readings WHERE ts >= :since ORDER BY ts") suspend fun since(since: Long): List<Reading>
    @Query("SELECT * FROM readings WHERE ts BETWEEN :from AND :to ORDER BY ABS(ts - :target) LIMIT 1")
    suspend fun nearest(from: Long, to: Long, target: Long): Reading?
    @Query("DELETE FROM readings WHERE ts < :before") suspend fun deleteBefore(before: Long)
}

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS `marks` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `ts` INTEGER NOT NULL, `hpa` REAL, `note` TEXT NOT NULL)")
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_marks_ts` ON `marks` (`ts`)")
    }
}

@Database(entities = [Reading::class, Mark::class], version = 2, exportSchema = false)
abstract class Db : RoomDatabase() {
    abstract fun dao(): ReadingDao
    abstract fun markDao(): MarkDao

    companion object {
        @Volatile private var inst: Db? = null
        fun get(ctx: Context): Db = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, Db::class.java, "baroguard.db").addMigrations(MIGRATION_1_2).build().also { inst = it }
        }
    }
}
