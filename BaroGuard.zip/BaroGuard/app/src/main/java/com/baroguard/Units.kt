package com.baroguard

import java.util.Locale

const val HOUR = 3_600_000L

enum class PUnit(val label: String, private val k: Float, val dec: Int) {
    HPA("hPa", 1f, 1), MBAR("mbar", 1f, 1), INHG("inHg", 0.02953f, 2), MMHG("mmHg", 0.750062f, 1);

    fun conv(hpa: Float) = hpa * k
    fun fmt(hpa: Float): String = String.format(Locale.getDefault(), "%.${dec}f", conv(hpa))
    fun fmtDelta(hpa: Float): String = String.format(Locale.getDefault(), "%+.${dec}f", conv(hpa))
}

data class Trend(val label: String, val arrow: String, val ratePerHour: Float)

/** Trend over the last ~3 hours. Rate is in hPa per hour. */
fun computeTrend(list: List<Reading>): Trend? {
    val last = list.lastOrNull() ?: return null
    val ref = list.firstOrNull { it.ts >= last.ts - 3 * HOUR } ?: last
    val hrs = (last.ts - ref.ts) / HOUR.toFloat()
    if (hrs < 0.25f) return Trend("Steady", "→", 0f)
    val r = (last.hpa - ref.hpa) / hrs
    return when {
        r >= 0.3f -> Trend("Rising", "↑", r)
        r <= -0.3f -> Trend("Falling", "↓", r)
        else -> Trend("Steady", "→", r)
    }
}

/** One monotonic run of the graph: from one turning point (rise <-> fall) to the next. Rate is hPa per hour. */
data class Seg(val pts: List<Reading>, val rate: Float)

/**
 * Splits readings at turning points. A direction change only counts once pressure has moved back by at least
 * [thr] hPa, so sensor jitter does not create tiny segments.
 */
fun computeSegments(list: List<Reading>, thr: Float = 0.4f): List<Seg> {
    if (list.size < 2) return emptyList()
    val piv = mutableListOf(0)
    var dir = 0
    var lo = 0
    var hi = 0
    var ext = 0
    for (i in 1 until list.size) {
        val h = list[i].hpa
        when (dir) {
            0 -> {
                if (h < list[lo].hpa) lo = i
                if (h > list[hi].hpa) hi = i
                if (h - list[lo].hpa >= thr) { if (lo != 0) piv.add(lo); dir = 1; ext = i }
                else if (list[hi].hpa - h >= thr) { if (hi != 0) piv.add(hi); dir = -1; ext = i }
            }
            1 -> if (h > list[ext].hpa) ext = i
                 else if (list[ext].hpa - h >= thr) { piv.add(ext); dir = -1; ext = i }
            else -> if (h < list[ext].hpa) ext = i
                    else if (h - list[ext].hpa >= thr) { piv.add(ext); dir = 1; ext = i }
        }
    }
    if (piv.last() != list.lastIndex) piv.add(list.lastIndex)
    return piv.zipWithNext().mapNotNull { (a, b) ->
        val dt = (list[b].ts - list[a].ts) / HOUR.toFloat()
        if (b <= a || dt <= 0f) null
        else Seg(list.subList(a, b + 1), (list[b].hpa - list[a].hpa) / dt)
    }
}

/** Pressure (hPa) on the drawn line at time [ts], interpolated between neighbouring readings; null if out of range. */
fun pressureAt(list: List<Reading>, ts: Long): Float? {
    if (list.isEmpty()) return null
    val i = list.indexOfFirst { it.ts >= ts }
    if (i < 0) return list.last().takeIf { ts - it.ts < 2 * HOUR }?.hpa
    if (i == 0 || list[i].ts == ts) return list[i].takeIf { it.ts - ts < 2 * HOUR }?.hpa
    val a = list[i - 1]
    val b = list[i]
    return a.hpa + (b.hpa - a.hpa) * (ts - a.ts) / (b.ts - a.ts).toFloat()
}
