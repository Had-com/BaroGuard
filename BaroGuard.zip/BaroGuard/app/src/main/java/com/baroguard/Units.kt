package com.baroguard

import java.util.Locale

const val HOUR = 3_600_000L

enum class PUnit(val label: String, private val k: Float, val dec: Int) {
    HPA("hPa", 1f, 1), MBAR("mbar", 1f, 1), INHG("inHg", 0.02953f, 2), MMHG("mmHg", 0.750062f, 1);

    fun conv(hpa: Float) = hpa * k
    fun fmt(hpa: Float): String = String.format(Locale.getDefault(), "%.${dec}f", conv(hpa))
    fun fmtDelta(hpa: Float): String = String.format(Locale.getDefault(), "%+.${dec}f", conv(hpa))
}

data class Trend(val label: String, val arrow: String, val ratePerHour: Float)

/** Trend over the last ~3 hours. Rate is in hPa per hour. */
fun computeTrend(list: List<Reading>): Trend? {
    val last = list.lastOrNull() ?: return null
    val ref = list.firstOrNull { it.ts >= last.ts - 3 * HOUR } ?: last
    val hrs = (last.ts - ref.ts) / HOUR.toFloat()
    if (hrs < 0.25f) return Trend("Steady", "→", 0f)
    val r = (last.hpa - ref.hpa) / hrs
    return when {
        r >= 0.3f -> Trend("Rising", "↑", r)
        r <= -0.3f -> Trend("Falling", "↓", r)
        else -> Trend("Steady", "→", r)
    }
}
