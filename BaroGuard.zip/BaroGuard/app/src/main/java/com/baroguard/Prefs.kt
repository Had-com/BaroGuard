package com.baroguard

import android.content.Context
import java.util.Calendar

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("baroguard", Context.MODE_PRIVATE)

    var intervalMin: Int
        get() = sp.getInt("interval", 15)
        set(v) { sp.edit().putInt("interval", v).apply() }
    var unit: PUnit
        get() = runCatching { PUnit.valueOf(sp.getString("unit", "HPA")!!) }.getOrDefault(PUnit.HPA)
        set(v) { sp.edit().putString("unit", v.name).apply() }
    /** Thresholds are stored in hPa. */
    var dropHpa: Float
        get() = sp.getFloat("drop", 2f)
        set(v) { sp.edit().putFloat("drop", v).apply() }
    var riseHpa: Float
        get() = sp.getFloat("rise", 2f)
        set(v) { sp.edit().putFloat("rise", v).apply() }
    var windowH: Int
        get() = sp.getInt("window", 3)
        set(v) { sp.edit().putInt("window", v).apply() }
    var sound: Boolean
        get() = sp.getBoolean("sound", true)
        set(v) { sp.edit().putBoolean("sound", v).apply() }
    var vibrate: Boolean
        get() = sp.getBoolean("vibrate", true)
        set(v) { sp.edit().putBoolean("vibrate", v).apply() }
    var highPriority: Boolean
        get() = sp.getBoolean("high", true)
        set(v) { sp.edit().putBoolean("high", v).apply() }
    var quietOn: Boolean
        get() = sp.getBoolean("quiet_on", false)
        set(v) { sp.edit().putBoolean("quiet_on", v).apply() }
    var quietStart: Int
        get() = sp.getInt("quiet_start", 22)
        set(v) { sp.edit().putInt("quiet_start", v).apply() }
    var quietEnd: Int
        get() = sp.getInt("quiet_end", 7)
        set(v) { sp.edit().putInt("quiet_end", v).apply() }
    var widgetBg: Int            // RGB, no alpha
        get() = sp.getInt("widget_bg", 0x1B2430)
        set(v) { sp.edit().putInt("widget_bg", v).apply() }
    var widgetAlpha: Int         // 0..255
        get() = sp.getInt("widget_alpha", 235)
        set(v) { sp.edit().putInt("widget_alpha", v).apply() }
    var monitorService: Boolean   // foreground service that keeps sampling while the app is closed
        get() = sp.getBoolean("monitor_service", true)
        set(v) { sp.edit().putBoolean("monitor_service", v).apply() }
    var widgetHours: Int
        get() = sp.getInt("widget_hours", 12)
        set(v) { sp.edit().putInt("widget_hours", v).apply() }

    fun lastAlert(k: String) = sp.getLong("last_$k", 0L)
    fun setLastAlert(k: String, t: Long) { sp.edit().putLong("last_$k", t).apply() }

    fun inQuietHours(): Boolean {
        if (!quietOn) return false
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return if (quietStart <= quietEnd) h in quietStart until quietEnd else h >= quietStart || h < quietEnd
    }
}
