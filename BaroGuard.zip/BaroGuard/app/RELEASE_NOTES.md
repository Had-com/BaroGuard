## What's new
- Fix: the widget and graph now keep updating while the app is closed. Android only gives apps barometer readings in the background while a notification is showing, so BaroGuard now runs a small monitoring service with an ongoing notification. It can be turned off in Settings > Background monitoring.
- Fix: marks are now a point on the graph line, at the pressure measured when the mark was added (app and widget).
- Fix: the 🔥 / ❄️ icon and rate now appear on every segment where they fit, in shorter forms on narrow segments, and are drawn on top of the line.
- Segments ignore small wobbles (under 0.4 hPa), so the graph shows fewer, clearer segments.
