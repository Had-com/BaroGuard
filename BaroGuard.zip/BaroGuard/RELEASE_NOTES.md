## What's new
- Graph colours are now fixed: pressure rising is red, pressure falling is blue (app and widget).
- Each segment's rate is written at the centre of the segment, with a hot icon for a positive rate and a cold icon for a negative rate.
- The trend text under the pressure value uses the same colours.
