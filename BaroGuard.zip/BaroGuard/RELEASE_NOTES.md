## What's new
- "Check for updates" now lists the main changes of every version you have not installed yet, newest first.
- Each release now carries its own summary of changes, written for that version.
- Widget: time-range buttons (1h to 24h), trend colours and a custom background colour with opacity.
- Widget graph: axes, units, per-segment rates, marks and highlighted strong rises and drops.
