# BaroGuard
Open this folder in Android Studio (Koala or newer), let Gradle sync, then Run on a device with a barometer.
Emulators have no pressure sensor, so you will see the "Barometer not available" screen there.

- Min SDK 26, target 35, Kotlin + Jetpack Compose, Room, WorkManager, AppWidget.
- Add the widget from the home-screen widget picker ("BaroGuard", 4x2, resizable).
- Replace the placeholder vector launcher icon via Android Studio > New > Image Asset if desired.

## Release notes
Edit `RELEASE_NOTES.md` before every upload. The build publishes its text as the release summary,
and the app shows it under Settings > App updates > Check for updates.
